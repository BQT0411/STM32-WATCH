#ifndef __DINO_H
#define __DINO_H
void Dino_Tick(void);
int DinoGame_Animation(void);
void DinoGame_Pos_Init(void);
void DinoGame_Pos_Init(void);
#endif