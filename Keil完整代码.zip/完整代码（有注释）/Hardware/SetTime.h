#ifndef __SETTIME_H
#define __SETTIME_H
int SetTime(void);
#endif